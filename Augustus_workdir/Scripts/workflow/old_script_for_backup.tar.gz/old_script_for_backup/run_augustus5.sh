#!/bin/bash
#PBS -N stitching
#PBS -l ncpus=1,walltime=00:30:00,storage=gdata/if89+gdata/xl04,mem=20GB
#PBS -j oe
#PBS -M z5205618@ad.unsw.edu.au
#PBS -m ae

# IMPORTANT  #
# Make sure to follow instructions at the end of run_augustus4.sh before running this script

# variables needed for this script
# ${workingdir}     path/to/workingdir
# ${genome}         path/to/masked_genome

module use /g/data/if89/apps/modulefiles
module load genometools/1.6.2 seqkit/2.3.1

# This generates a "temp_all" file with all the stitched genes
## stitching all the clusters on positive strand
cd ${workingdir}/Augustus/annotation_stitch
cat intersect_and_stitch/intersect5_pos.tsv | while read a; do last=$(echo $a | wc -w); one=1; lastone=$[last - one]; echo "$a" > temp_input; perl -i -pe "chomp if eof" temp_input; readarray -d $'\t' -t a < temp_input; for index in "${!a[@]}"; do if [ $index == 0 ]; then    \
$(grep -w "${a[$index]}" ../annotation/augustus.gff3 | grep 'gene\|mRNA\|transcription_start_site\|five_prime_utr\|start_codon\|CDS\|intron' > temp); \
elif [ $index == $lastone ]; then \
$(grep -w "${a[$index]}" ../annotation/augustus.gff3 | grep 'transcription_end_site\|stop_codon\|three_prime_utr\|CDS\|intron' | sed "s/${a[$index]}/${a[0]}/g" >> temp); \
else \
$(grep -w "${a[$index]}" ../annotation/augustus.gff3 | grep 'CDS\|intron' | sed "s/${a[$index]}/${a[0]}/g" >> temp); \
fi done; gt gff3 -sort -tidy -retainids -addintrons <(sed 's/g10024/g10023/g' temp | sed 's/CDS/exon/g') > temp2; grep "$(cut -f3,4,5 temp2 | grep intron | sort | uniq -u)" temp2 >> temp; gt gff3 -sort -tidy -retainids temp | grep -v "#" > temp2; endcoord=$(sort -n -r -k 5 temp2 | cut -f5 | head -n 1); \
perl process.pl | awk '$2=="."{$2="Inferred"} 1' OFS="\t" | awk '$3=="gene"{$5='$endcoord'} 1' OFS="\t" | awk '$3=="mRNA"{$5='$endcoord'} 1' OFS="\t" > temp3; \
cat temp3 >> temp_all; \
rm temp; \
rm temp2; \
rm temp3; done

## stitching all the clusters on negative strand
cd ${workingdir}/Augustus/annotation_stitch
cat intersect_and_stitch/intersect5_neg.tsv | while read a; do last=$(echo $a | wc -w); one=1; lastone=$[last - one]; echo "$a" > temp_input; perl -i -pe "chomp if eof" temp_input; readarray -d $'\t' -t a < temp_input; for index in "${!a[@]}"; do if [ $index == 0 ]; then    \
$(grep -w "${a[$index]}" ../annotation/augustus.gff3 | grep 'gene\|mRNA\|transcription_end_site\|three_prime_utr\|stop_codon\|CDS\|intron' > temp); \
elif [ $index == $lastone ]; then \
$(grep -w "${a[$index]}" ../annotation/augustus.gff3 | grep 'transcription_start_site\|start_codon\|five_prime_utr\|CDS\|intron' | sed "s/${a[$index]}/${a[0]}/g" >> temp); \
else \
$(grep -w "${a[$index]}" ../annotation/augustus.gff3 | grep 'CDS\|intron' | sed "s/${a[$index]}/${a[0]}/g" >> temp); \
fi done; gt gff3 -sort -tidy -retainids -addintrons <(sed 's/g10024/g10023/g' temp | sed 's/CDS/exon/g') > temp2; grep "$(cut -f3,4,5 temp2 | grep intron | sort | uniq -u)" temp2 >> temp; gt gff3 -sort -tidy -retainids temp | grep -v "#" > temp2; endcoord=$(sort -n -r -k 5 temp2 | cut -f5 | head -n 1); \
perl process.pl | awk '$2=="."{$2="Inferred"} 1' OFS="\t" | awk '$3=="gene"{$5='$endcoord'} 1' OFS="\t" | awk '$3=="mRNA"{$5='$endcoord'} 1' OFS="\t" > temp3; \
cat temp3 >> temp_all; \
rm temp; \
rm temp2; \
rm temp3; done

rm temp_input

# Script to get rid of all those single genes before stitching together
tr '\t' '\n' < intersect_and_stitch/intersect5_pos.tsv > single.lst
tr '\t' '\n' < intersect_and_stitch/intersect5_neg.tsv >> single.lst
sort single.lst | uniq > single2.lst
grep -v -w -f single2.lst ../annotation/augustus.gff3 > augustus2.gff3

# Now we merge augustus2.gff3 (which does not have those single genes), and temp_all (which contains those single genes but stitched), then sort them with genometools
gt gff3 -retainids -tidy <(cat augustus2.gff3 temp_all) > augustus_stitched.gff3
source ~/.bashrc
conda activate funannotate
funannotate util gff2prot -g augustus_stitched.gff3 -f ${genome} | seqkit sort -N > augustus_stitched_protein.fa
