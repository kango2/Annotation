#!/bin/bash
#PBS -N create_training_set4
#PBS -l ncpus=1,walltime=12:00:00,storage=gdata/if89+gdata/xl04,mem=20GB,jobfs=20GB
#PBS -j oe
#PBS -M z5205618@ad.unsw.edu.au
#PBS -m ae

# variables needed when running qsub
# ${workingdir}      path/to/working_directory

# Making training set to use for training augustus and utr training augustus
module use /g/data/if89/apps/modulefiles
module load blast/2.11.0 Augustus/3.4.0 perllib/v5.26.3 blat/37 RepeatMasker/4.1.2-p1 scipio/1.4 pblat/2.5 pslCDnaFilter/0 parallel/20191022 genometools/1.6.2

cd ${workingdir}/Exonerate/annotation/working_dir

cp ${workingdir}/Exonerate/cDNA_out/BASDU_Brain_all_R.trinity.Trinity.exonerate.target.genes.gff3 .
cp ${workingdir}/Exonerate/CDS_filtered_out/CDS_filtered_final.fa.exonerate.target.genes.gff3 .

# Exonerate can sometime have multiple alignments for the same transcript (even with bestn=1 due to identical alignment score), therefore we need to filter them out 
grep "gene" CDS_filtered_final.fa.exonerate.target.genes.gff3 | cut -f9 | cut -f4 -d ";" | sed 's/from=//g' | sort | uniq -d | sort > CDS_duplicated
grep -v -w -f CDS_duplicated CDS_filtered_final.fa.exonerate.target.genes.gff3 > CDS_filtered_final.fa.exonerate.target.genes2.gff3

grep "gene" BASDU_Brain_all_R.trinity.Trinity.exonerate.target.genes.gff3 | cut -f9 | cut -f4 -d ";" | sed 's/from=//g' | sort | uniq -d | sort > cDNA_duplicated
grep -v -w -f cDNA_duplicated BASDU_Brain_all_R.trinity.Trinity.exonerate.target.genes.gff3 > BASDU_Brain_all_R.trinity.Trinity.exonerate.target.genes2.gff3
## also filter them out in the hints file
grep -v -w -f cDNA_duplicated ${workingdir}/Exonerate/cDNA_out/BASDU_Brain_all_R.trinity.Trinity.exonerate.target.hints.gff3 > ${workingdir}/Exonerate/cDNA_out/BASDU_Brain_all_R.trinity.Trinity.exonerate.target.hints_unique.gff3
## move and rename hints file to a more identifiable place
mv ${workingdir}/Exonerate/cDNA_out/BASDU_Brain_all_R.trinity.Trinity.exonerate.target.hints_unique.gff3 ${workingdir}/Augustus/hints/exonerate_hints.gff3

# Now we modify the cDNA and CDS gff3 output from exonerate to generate a training set for training augustus
## replacing exon to CDS in 3rd column | #replacing .e to .cds in 9th column | #selecting only the CDS
awk '$3=="exon"{$3="CDS"} 1' OFS="\t"   CDS_filtered_final.fa.exonerate.target.genes2.gff3 | sed 's/\.e/\.cds/g' | grep CDS > CDS.gff3

## selecting genes that are in both exon and CDS gff3
grep "gene" BASDU_Brain_all_R.trinity.Trinity.exonerate.target.genes2.gff3 | cut -f9 | cut -d ";" -f4 | sed 's/from=//g' | sort | uniq -u > Trinity_all.txt
grep "gene" CDS_filtered_final.fa.exonerate.target.genes2.gff3 | cut -f9 | cut -d ";" -f4 | sed 's/from=//g' | sort | uniq -u > CDS.txt
comm -12 <(sort Trinity_all.txt) <(sort CDS.txt) > both.txt

echo '##gff-version 3' > merge.gff3
grep -w -f both.txt BASDU_Brain_all_R.trinity.Trinity.exonerate.target.genes2.gff3 >> merge.gff3
grep -w -f both.txt CDS.gff3 >> merge.gff3

gt gff3 -sortlines -tidy -retainids merge.gff3 > merge2.gff3
gt gff3 -retainids merge2.gff3 > merge3.gff3

## this script adds the inferred UTRs from exon-CDS differences
python3 ${workingdir}/Scripts/addUTRs.py ${workingdir}/Exonerate/annotation/working_dir/merge3.gff3 ${workingdir}/Exonerate/annotation/working_dir/merge3_with_UTRs.gff3
sed -i 's/exonerate:est2genome/est2genome/g' merge3_with_UTRs.gff3 

grep mRNA merge3_with_UTRs.gff3 | cut -f9 | cut -d ';' -f1 | sed 's/ID=//g' > IDs_in_gff.txt
grep -w -f IDs_in_gff.txt ${workingdir}/Simple_header/trinity_all/header.map >> header_filtered.map

tr -d '\r' < header_filtered.map | while read a b; do sed -i s/$b\\b/$a/g merge3_with_UTRs.gff3; done

## grep-ing the relevant gff3 information from annotation file needed for training augustus
grep -v -E 'exon|gene|mRNA' merge3_with_UTRs.gff3 > ${workingdir}/Exonerate/annotation/CDS_with_UTR/CDS_with_UTRs.gff3
grep -v -E 'exon|UTR|gene|mRNA' merge3_with_UTRs.gff3 > ${workingdir}/Exonerate/annotation/CDS_only/CDS.gff3

## we now select only genes that have both 3' and 5' utrs for training augustus
grep "three_prime_UTR" merge3_with_UTRs.gff3 | cut -f9 | cut -d "." -f1 | sort | uniq > all3
grep "five_prime_UTR" merge3_with_UTRs.gff3 | cut -f9 | cut -d "." -f1 | sort | uniq > all5

comm -12 <(sort all3) <(sort all5) > bothutr.lst

sed -i "s/ID=//g" bothutr.lst

# Turning gffs into genbank format with 2000 bases of flanking region
cd ${workingdir}/Exonerate/annotation/CDS_only
gff2gbSmallDNA.pl CDS.gff3 ${workingdir}/Simple_header/genome/Target_genome_clean.fa 2000 training.gb --good=${workingdir}/Exonerate/annotation/working_dir/bothutr.lst
cd ${workingdir}/Exonerate/annotation/CDS_with_UTR
gff2gbSmallDNA.pl CDS_with_UTRs.gff3 ${workingdir}/Simple_header/genome/Target_genome_clean.fa 2000 training_with_utr.gb --good=${workingdir}/Exonerate/annotation/working_dir/bothutr.lst

## randomly choose 500 for training
cd ${workingdir}/Exonerate/annotation/CDS_only
## this generates training.gb.test with 500 genes
## and training.gb.train with the rest ~4500 genes
randomSplit.pl training.gb 500
## we then further split the training.gb.test into 200 for evaluation and training, whilst the other 300 for training only
## evaluation is the step that takes very long whereas training is fast, but since we now have a way to use the parallel perl module we can use more
randomSplit.pl training.gb.test 200

#similarily for generating UTR training
cd ${workingdir}/Exonerate/annotation/CDS_with_UTR
randomSplit.pl training_with_utr.gb 500
randomSplit.pl training_with_utr.gb.test 200

