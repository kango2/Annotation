#!/bin/bash
#PBS -N create_training_set3
#PBS -l ncpus=1,walltime=00:20:00,storage=gdata/if89+gdata/xl04,mem=20GB,jobfs=20GB
#PBS -j oe
#PBS -M z5205618@ad.unsw.edu.au
#PBS -m ae

# variables needed when running qsub
# ${workingdir}      path/to/working_directory

# This script generate transcript clusters from the all_vs_all blast result, then keep only one transcript in each cluster.
# Also generates the command to run exonerate for filtered cds
# name your .csv file "table.csv" (default) and put it in ${workingdir}

module use /g/data/if89/apps/modulefiles
module load blast/2.11.0 Augustus/3.4.0 perllib/v5.26.3 blat/37 RepeatMasker/4.1.2-p1 scipio/1.4 pblat/2.5 pslCDnaFilter/0 parallel/20191022 genometools/1.6.2

cd ${workingdir}/Trinity_filter/third_filter
mv ${workingdir}/table.csv .

# this script will generate one transcript cluster in each new line
cat table.csv | perl -lne '$_=~s/\"//g; @a=split(",",$_); next if ($_=~/query/); $g{$a[1]}{$a[1]}=""; $g{$a[2]}{$a[2]}=""; $g{$a[1]}{$a[2]}=""; $g{$a[2]}{$a[1]}=""; END {foreach $v (sort keys %g) { print join("\t", map { $_ } sort keys %{$g{$v}})}}' | sort | uniq > cluster.txt

# removing the first entry in each line (removing one transcript in each cluster)
perl -pe 's/.*?\t//' cluster.txt > cluster2.txt

# turning all transcripts in cluster2 into a list
tr '\t' '\n' < cluster2.txt > cluster3.txt

# removing duplicated entries
sort cluster3.txt | uniq -u > cluster4.txt



# Now generating commands to run exonerate for the filtered CDS, DO NOT run this exonerate commands yet. READ the end of this script

cd ${workingdir}/Scripts/exonerate
echo cd ${workingdir}/Scripts > exonerate_CDS_job.txt
echo First CDS command to run':' >> exonerate_CDS_job.txt
echo for i in ${workingdir}/Trinity_filter/results/CDS_filtered_final.fa';' do inputfasta='$(realpath $i)'';' for c in 1 241 481';' \
do qsub -P xl04 -o ${workingdir}/Exonerate/log \
-v querychunktotal=720,querychunkstart='$c',querychunkend='$((c+239))',outputdir=${workingdir}/Exonerate/CDS_filtered_out,inputfasta='${inputfasta}',targetgenome=${workingdir}/Simple_header/genome/Target_genome_clean.fa runexonerate.sh';' done';' done >> exonerate_CDS_job.txt
echo Second CDS command to run':' >> exonerate_CDS_job.txt
echo perl processexonerate.pl -inputfasta ${workingdir}/Trinity_filter/results/CDS_filtered_final.fa -outputdir ${workingdir}/Exonerate/CDS_filtered_out -targetgenome ${workingdir}/Simple_header/genome/Target_genome_clean.fa -querychunktotal 720 -hintpriority 4 -hintsource E >> exonerate_CDS_job.txt



# download cluster4.txt into your R studio folder and continue with the create_training_set1.sh.R script
# after that, you have a filtered list of cDNA, CDS and peptide
# upload the cDNA, CDS and peptide fasta to ${workingdir}/Trinity_filter/results, name them cDNA_filtered_final.fa CDS_filtered_final.fa peptide_filtered_final.fa
# after the three files have been uploaded to ${workingdir}/Trinity_filter/results, run the commands in ${workingdir}/Scripts/exonerate/exonerate_CDS_job.txt

# continue with create_training_set4.sh when the exonerate job for CDS finishes
