#!/bin/bash
#PBS -N run_augustus1
#PBS -l ncpus=16,walltime=30:00:00,storage=gdata/if89+gdata/xl04,mem=50GB,jobfs=50GB
#PBS -j oe
#PBS -M z5205618@ad.unsw.edu.au
#PBS -m ae

# This script takes ~17hrs to run
# It essentially combines run_augustus1 and run_augustus2 from the old_script_for_backup folder into one script,
# variables needed when running qsub
# ${workingdir}     path/to/working_directory
# ${species}        your species name, use _ if there is a space

module use /g/data/if89/apps/modulefiles
module load Augustus/3.4.0 perllib/v5.26.3 blat/37 RepeatMasker/4.1.2-p1 scipio/1.4 pblat/2.5 pslCDnaFilter/0 parallel/20191022

cd ${workingdir}
rsync -a $AUGUSTUS_CONFIG_PATH/ Augustus/config/
export AUGUSTUS_CONFIG_PATH=${workingdir}/Augustus/config

# First we make parameters files for the new species
new_species.pl --species=${species}
## an initial training using ~4500 genes, this is fast
cd Augustus/training
etraining --species=${species} ${workingdir}/Exonerate/annotation/CDS_only/training.gb.train
augustus --species=${species} ${workingdir}/Exonerate/annotation/CDS_only/training.gb.test | tee first_evaluation.out
grep -A 22 Evaluation first_evaluation.out > first_evaluation.report

# Now we optimize with 500 genes, 200 for evaluation and all 500 for training, the max 5 rounds has been chosen but it will finish earlier if no improvement are found
## the log file optimize.out can be opened for inspection when the job is running to check progression
optimize_augustus.pl \
--species=${species} \
--cpus=${PBS_NCPUS} \
--rounds=5 \
${workingdir}/Exonerate/annotation/CDS_only/training.gb.test.test \
--onlytrain=${workingdir}/Exonerate/annotation/CDS_only/training.gb.test.train \
> optimize.out

# Retrain after optimization
etraining --species=${species} ${workingdir}/Exonerate/annotation/CDS_only/training.gb.test


#we now optimize the utr parameters
cd ${workingdir}/Augustus/utr_training
#first evaluation before training
optimize_augustus.pl \
--species=${species} \
--cpus=${PBS_NCPUS} \
--rounds=5 \
${workingdir}/Exonerate/annotation/CDS_with_UTR/training_with_utr.gb.test.test \
--onlytrain=${workingdir}/Exonerate/annotation/CDS_with_UTR/training_with_utr.gb.test.train \
--UTR=on \
--metapars=${workingdir}/Augustus/config/species/${species}/${species}_metapars.utr.cfg \
--trainOnlyUtr=1 > optimize_utr.out

#retrain after optimization
etraining --species=${species} --UTR=on ${workingdir}/Exonerate/annotation/CDS_with_UTR/training_with_utr.gb.test

#final evaluation
augustus --species=${species} --UTR=on ${workingdir}/Exonerate/annotation/CDS_with_UTR/training_with_utr.gb.test | tee UTR_evaluation.out
grep -A 22 Evaluation UTR_evaluation.out > UTR_evaluation.report



#splitting genome into chunks for parallel augustus execution

genome_size=$(tr -d '\n' < <(grep -v ">" ${workingdir}/Simple_header/genome/Target_genome_clean.fa) | wc -c)
min_size=$(expr \( ${genome_size} / ${PBS_NCPUS} \) + 1)
splitMfasta.pl --minsize=${min_size} ${workingdir}/Simple_header/genome/Target_genome_clean.fa --outputpath=${workingdir}/Augustus/split_genome
