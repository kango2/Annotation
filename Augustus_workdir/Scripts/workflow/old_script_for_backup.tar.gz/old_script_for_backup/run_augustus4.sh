#!/bin/bash
#PBS -N run_augustus4
#PBS -l ncpus=12,walltime=1:00:00,storage=gdata/if89+gdata/xl04,mem=60GB,jobfs=60GB
#PBS -j oe
#PBS -M z5205618@ad.unsw.edu.au
#PBS -m ae

# variables needed
# ${workingdir} path/to/working/directory
# ${anolis}     path/to/anolis/cDNA
# ${genome}     path/to/genome

# This script prepares the candidates for stitching

module use /g/data/if89/apps/modulefiles
module load Augustus/3.4.0 perllib/v5.26.3 blat/37 RepeatMasker/4.1.2-p1 scipio/1.4 pblat/2.5 pslCDnaFilter/0 parallel/20191022 blast/2.11.0

# First, we blast anolis cDNA to bassiana genome
## making database
cd ${workingdir}/Augustus/annotation_stitch/blast/database
makeblastdb -in ${genome} \
-parse_seqids \
-title "genome" -dbtype nucl \
-out ${workingdir}/Augustus/annotation_stitch/blast/database/genome

## blast anolis cDNA to genome
blastn -query ${anolis} \
-db ${workingdir}/Augustus/annotation_stitch/blast/database/genome \
-max_target_seqs 1 \
-evalue 1e-6 \
-parse_deflines \
-outfmt 6 \
-num_threads ${PBS_NCPUS} \
-out ${workingdir}/Augustus/annotation_stitch/blast/anolis_cDNA_to_BASDU.tsv

cd ${workingdir}/Augustus/annotation_stitch/blast/
# Add gene id immediately following the transcript id, separated by "|" , then turns the blast tsv output into a bed file
join <(sort anolis_cDNA_to_BASDU.tsv) <(grep ">" ${anolis} | cut -f1,4 -d' ' | sed 's/ /\t/g' | sed 's/>//g' | sort) -t $'\t' -o1.1,2.2,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,1.10,1.11,1.12,1.13,1.14 | perl -pe 's/\t/|/' | perl -lne '@a=split("\t", $_); print "$a[1]\t". (($a[8] < $a[9]) ? $a[8] : $a[9] )."\t".(($a[8] < $a[9]) ? $a[9] : $a[8])."\t$a[0]\t$a[11]\t".(($a[8] < $a[9]) ? "+" : "-" )' > anolis_cDNA_to_BASDU.bed
mv anolis_cDNA_to_BASDU.bed ${workingdir}/Augustus/annotation_stitch/intersect_and_stitch/anolis_cDNA_to_BASDU.bed

# Generating the list of genes to be stitched together
cd ${workingdir}/Augustus/annotation_stitch/intersect_and_stitch
awk -F "\t" '{print $1"\t"$4"\t"$5"\t"$9"\t"$6"\t"$7}' ../../annotation/augustus_for_bedintersect.gff3 > augustus.bed
module load bedtools/2.28.0

# -s so it's strand specific, -wa and -wb to output both input bed files.
bedtools intersect -a anolis_cDNA_to_BASDU.bed -b augustus.bed -wa -wb -s > intersect

cut -f4,10 intersect | sed 's/;/\t/g' | cut -f1,3 | sed 's/Parent=//g' | sed 's/.t1//g' | sort | uniq | sort | awk '{ printf "%s", (NR==1 || pre!=$1? (NR>1? ORS:"")$1: "") OFS $2; pre=$1 }
    END  { print "" }' | sed 's/ /\t/g' | awk 'NF>=3' > intersect2
cut -f2- -d "|" intersect2 | sort | uniq > intersect3.tsv

# Since the annotation file are in order, the IDs we grep will also be in order, this generates a long list of .tsv file of consecutive IDs
grep gene ../../annotation/augustus.gff3 | grep "+" | cut -f9 | sed 's/;//g' | sed 's/ID=//g' | paste -s -d "\t" > consecutive_positive.tsv
grep gene ../../annotation/augustus.gff3 | grep "-" | cut -f9 | sed 's/;//g' | sed 's/ID=//g' | paste -s -d "\t" > consecutive_negative.tsv

# We now try grep-ing each intersect cluster from the consecutive IDs, cluster contains neighbouring genes (consecutive IDs) if it can be grep-ed from the consecutive IDs
## we then filter for clusters that can be grep-ed (with yes)
cut -f2- intersect3.tsv | while read a; do if grep -q "$a" consecutive_positive.tsv; then echo -e yes'\t'"$a"; else echo -e no'\t'"$a"; fi done > intersect4_pos.tsv
grep yes intersect4_pos.tsv | cut -f2- | sort | uniq > intersect5_pos.tsv

cut -f2- intersect3.tsv | while read a; do if grep -q "$a" consecutive_negative.tsv; then echo -e yes'\t'"$a"; else echo -e no'\t'"$a"; fi done > intersect4_neg.tsv
grep yes intersect4_neg.tsv | cut -f2- | sort | uniq > intersect5_neg.tsv

cd ${workingdir}/Augustus/annotation_stitch
export temppath=${workingdir}/Augustus/annotation_stitch/temp
sed -i "s|inputpath|${temppath}|g" process.pl

# After this is done, manually filter intersect5_pos.tsv and intersect5_neg.tsv to keep only the longest cluster.
# For example, if (g1 g2), (g2 g3) and (g1 g2 g3) are all in the list, then remove (g1 g2) and (g2 g3), keeping only (g1 g2 g3)
