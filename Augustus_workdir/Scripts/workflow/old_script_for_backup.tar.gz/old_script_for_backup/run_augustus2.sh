#!/bin/bash
#PBS -N run_augustus2
#PBS -l ncpus=16,walltime=24:00:00,storage=gdata/if89+gdata/xl04,mem=50GB,jobfs=50GB
#PBS -j oe
#PBS -M z5205618@ad.unsw.edu.au
#PBS -m ae

# This script takes ~11hr to run
# variables needed when running qsub
# ${workingdir}     path/to/working_directory
# ${species}        your species name, use _ if there is a space

source ~/.bashrc
conda activate parallelforkmanager
module use /g/data/if89/apps/modulefiles
module load Augustus/3.4.0 perllib/v5.26.3 blat/37 RepeatMasker/4.1.2-p1 scipio/1.4 pblat/2.5 pslCDnaFilter/0 parallel/20191022

export AUGUSTUS_CONFIG_PATH=${workingdir}/Augustus/config

#we now optimize the utr parameters
cd ${workingdir}/Augustus/utr_training
#first evaluation before training
optimize_augustus.pl \
--species=${species} \
--cpus=${PBS_NCPUS} \
--rounds=5 \
${workingdir}/Exonerate/annotation/CDS_with_UTR/training_with_utr.gb.test.test \
--onlytrain=${workingdir}/Exonerate/annotation/CDS_with_UTR/training_with_utr.gb.test.train \
--UTR=on \
--metapars=${workingdir}/Augustus/config/species/${species}/${species}_metapars.utr.cfg \
--trainOnlyUtr=1 > optimize_utr.out

#retrain after optimization
etraining --species=${species} --UTR=on ${workingdir}/Exonerate/annotation/CDS_with_UTR/training_with_utr.gb.test

#final evaluation
augustus --species=${species} --UTR=on ${workingdir}/Exonerate/annotation/CDS_with_UTR/training_with_utr.gb.test | tee UTR_evaluation.out
grep -A 22 Evaluation UTR_evaluation.out > UTR_evaluation.report
