#!/bin/bash
#PBS -N create_training_set1
#PBS -l ncpus=16,walltime=16:00:00,storage=gdata/if89+gdata/xl04,mem=50GB
#PBS -j oe
#PBS -M z5205618@ad.unsw.edu.au
#PBS -m ae

# variables needed when running qsub
# ${workingdir}      path/to/working_directory
# ${targetgenome}    path/to/target_genome
# ${trinity_out}     path/to/trinity.out.fa
# Example of qsub command:
# qsub -P xl04 -v workingdir=A,targetgenome=B create_training_set1

module use /g/data/if89/apps/modulefiles
module load blast/2.11.0 Augustus/3.4.0 perllib/v5.26.3 blat/37 RepeatMasker/4.1.2-p1 scipio/1.4 pblat/2.5 pslCDnaFilter/0 parallel/20191022 genometools/1.6.2

# simplifying fasta headers for augustus, augustus can potentially fail with complex fasta headers
## simplifying genome headers
cd ${workingdir}/Simple_header/genome
cp ${targetgenome} .
simplifyFastaHeaders.pl ${targetgenome} Sequence Target_genome_clean.fa header.map
sed -i 's/>//g' header.map
## simplifying trinity headers
cd ${workingdir}/Simple_header/trinity_all
cp ${trinity_out} .
simplifyFastaHeaders.pl ${trinity_out} Transcript Trinity_all_clean.fa header.map
sed -i 's/>//g' header.map
sed -i 's/ .*//' header.map

# generating exonerate command to run manually, this will generate the hint files and part of the training annotation file needed later
cd ${workingdir}/Scripts/exonerate
echo cd ${workingdir}/Scripts > exonerate_Trinity_all_job.txt
echo First cDNA command to run':' >> exonerate_Trinity_all_job.txt
echo for i in ${trinity_out}';' do inputfasta='$(realpath $i)'';' for c in 1 241 481';' \
do qsub -P xl04 -o ${workingdir}/Exonerate/log \
-v querychunktotal=720,querychunkstart='$c',querychunkend='$((c+239))',outputdir=${workingdir}/Exonerate/cDNA_out,inputfasta='${inputfasta}',targetgenome=${workingdir}/Simple_header/genome/Target_genome_clean.fa runexonerate.sh';' done';' done >> exonerate_Trinity_all_job.txt
echo Second cDNA command to run':' >> exonerate_Trinity_all_job.txt
echo perl processexonerate.pl -inputfasta ${trinity_out} -outputdir ${workingdir}/Exonerate/cDNA_out -targetgenome ${workingdir}/Simple_header/genome/Target_genome_clean.fa -querychunktotal 720 -hintpriority 4 -hintsource E >> exonerate_Trinity_all_job.txt


# Filtering the trinity output for high quality transcripts
cd ${workingdir}/Trinity_filter/first_filter/database
cp ${workingdir}/uniprot_sprot.fasta .
## making database
makeblastdb -in ${workingdir}/Trinity_filter/first_filter/database/uniprot_sprot.fasta \
-parse_seqids \
-title "uniprot_sprot" -dbtype prot \
-out ${workingdir}/Trinity_filter/first_filter/database/uniprot_sprot
## blasting trinity.out to uniprot fasta
cd ..
cd blast
blastx -query ${trinity_out} \
-db ${workingdir}/Trinity_filter/first_filter/database/uniprot_sprot \
-parse_deflines \
-outfmt 6 \
-max_target_seqs 1 \
-num_threads ${PBS_NCPUS} \
-out ${workingdir}/Trinity_filter/first_filter/blast/output.tsv
## translating output
perl ${workingdir}/Scripts/blastxtranslations.pl ${trinity_out} \
${workingdir}/Trinity_filter/first_filter/database/uniprot_sprot.fasta \
${workingdir}/Trinity_filter/first_filter/blast/output.tsv \
Trinity_all

# This script generates the exonerate commands to run for cDNA, it is located in ${workingdir}/Scripts/exonerate/exonerate_Trinity_all_job.txt
# Run the commands in that file manually

# This script generates 3 output files listed below, download them to your R studio folder
# 1. Trinity_all.cDNA.all.fa        same as input
# ${workingdir}/Trinity_filter/first_filter/blast/Trinity_all_clean.cdna.all.fa
# 2. Trinity_all.cds.all.fa         only the cds
# ${workingdir}/Trinity_filter/first_filter/blast/Trinity_all_clean.cds.all.fa
# 3. Trinity_all.pep.all.fa         the translated peptide
# ${workingdir}/Trinity_filter/first_filter/blast/Trinity_all_clean.cdna.all.fa

# start filtering in R studio with create_training_set1.sh.R
# continue with create_training_set2.sh after filtering in R is done
