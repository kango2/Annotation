#!/bin/bash
#PBS -N Part3_RunningAugustus
#PBS -l ncpus=16,walltime=24:00:00,storage=gdata/if89+gdata/xl04,mem=60GB,jobfs=60GB
#PBS -j oe
#PBS -M z5205618@ad.unsw.edu.au
#PBS -m ae

# IMPORTANT: execute the commands in run_augustus_prep.manual before running this script
# variables needed when running qsub
# ${workingdir}     path/to/working_directory
# ${species}        your species name, use _ if there is a space

# Running augustus in parallel, also processing the output gff for stitching

module use /g/data/if89/apps/modulefiles
module load Augustus/3.4.0 perllib/v5.26.3 blat/37 RepeatMasker/4.1.2-p1 scipio/1.4 pblat/2.5 pslCDnaFilter/0 parallel/20191022

export AUGUSTUS_CONFIG_PATH=${workingdir}/Augustus/config

# This generates the augustus commands
cd ${workingdir}/Augustus/split_genome
for i in $(ls -1v Target_genome_clean.split.* | sed 's/Target_genome_clean.split.//g' | sed 's/\.fa//g'); do echo augustus --species=${species} --softmasking=1 --UTR=on --print_utr=on --hintsfile=${workingdir}/Augustus/hints/exonerate_hints.gff3 --extrinsicCfgFile=${workingdir}/Augustus/config/extrinsic/extrinsic.MPE.cfg --exonnames=off --stopCodonExcludedFromCDS=t --AUGUSTUS_CONFIG_PATH=${workingdir}/Augustus/config ${workingdir}/Augustus/split_genome/Target_genome_clean.split."$i".fa ">" ${workingdir}/Augustus/annotation/aug"$i".out >> ${workingdir}/Scripts/augustus_parallel/Augustus_parallel_script.txt; done

# This runs the commands in parallel
cd ${workingdir}/Scripts/augustus_parallel
cat Augustus_parallel_script.txt | parallel --jobs ${PBS_NCPUS} {}

# This merges the output and process them
cd ${workingdir}/Augustus/split_genome
for i in $(ls -1v Target_genome_clean.split.* | sed 's/Target_genome_clean.split.//g' | sed 's/\.fa//g'); do cat ${workingdir}/Augustus/annotation/aug"$i".out >> ${workingdir}/Augustus/annotation/aug.out; done
cd ${workingdir}/Augustus/annotation
cat aug.out | /g/data/if89/apps/Augustus/3.4.0/scripts/join_aug_pred.pl > augustus.gff
perl /g/data/if89/apps/Augustus/3.4.0/scripts/getAnnoFasta.pl augustus.gff
grep -v "#" augustus.gff > augustus.gtf

# This changes the contig name in augustus.gtf back to their original name (they were changed to a cleaner name whilst running augustus)
grep -w -f <(cut -f1 augustus.gtf | sort | uniq) ${workingdir}/Simple_header/genome/header.map > filtered_header
awk '{print "s/"$1"\\b/"$2"/g"}' filtered_header > filtered_header2
sed -i -f filtered_header2 augustus.gtf

# This outputs a gff3 file from the gtf file
gtf2gff.pl < augustus.gtf --out=augustus.gff3 --gff3

# This prepares for bedintersect which is needed for stitching
grep -w 'CDS\|three_prime_utr\|five_prime_utr' augustus.gff3 > augustus_for_bedintersect.gff3
