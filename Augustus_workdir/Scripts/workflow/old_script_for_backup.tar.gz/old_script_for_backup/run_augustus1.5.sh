#!/bin/bash
#PBS -N hints
#PBS -l ncpus=12,walltime=5:00:00,storage=gdata/if89+gdata/xl04,mem=120GB,jobfs=20GB
#PBS -j oe
#PBS -M z5205618@ad.unsw.edu.au
#PBS -m ae

module use /g/data/if89/apps/modulefiles

module load Augustus/3.4.0 perllib/v5.26.3 blat/37 RepeatMasker/4.1.2-p1 scipio/1.4 pblat/2.5 pslCDnaFilter/0 parallel/20191022

###### this can be run manually as it's faster that way

#This script generates miscellaneous files that are needed for augustus down the line, it can be run anytime after create_training_set4.sh
#probably good to run at the same time as run_augustus1.sh
cd ${workingdir}/Augustus
#splitting the genome, this does not take long and can probably be executed manually
#calculate minsize by doing =int((grep -v ">" $genome | wc -c)/$cpus)+1
#which is 1506223268/24 +1 = 62859303
#this generate 10 chunks
#in this pipeline we set minsize=10Mbp and it splits the genome into 16 parts which is faster for parallel execution
splitMfasta.pl --minsize=10000000 ${workingdir}/Simple_header/genome/Target_genome_clean.fa --outputpath=${workingdir}/Augustus/split_genome

###### Below is outdated, no need to run it, we use exonerate output for hints instead

#script to generate hints (this will be changed to include more hints)
cd ${workingdir}/Simple_header/cDNA_filtered
cp ${workingdir}/Trinity_filter/results/cDNA_filtered_final.fa .
sed 's/ .*//' cDNA_filtered_final.fa > cDNA_filtered_final_clean.fa
grep '>' cDNA_filtered_final_clean.fa | sed 's/>//g' | sort -u > IDs.txt
cat IDs.txt | parallel --jobs ${PBS_NCPUS} grep -w {} ${workingdir}/Simple_header/trinity_all/header.map >> header_filtered.map
tr -d '\r' < header_filtered.map | while read a b; do sed -i s/$b\\b/$a/g cDNA_filtered_final_clean.fa; done

cd ${workingdir}/Augustus/hints
pblat -threads=${PBS_NCPUS} -minIdentity=92 ${workingdir}/Simple_header/Target_genome_clean.fa ${workingdir}/Simple_header/cDNA_filtered/cDNA_filtered_final_clean.fa cdna.psl
pslCDnaFilter -maxAligns=1 cdna.psl cdna.f.psl
cat cdna.f.psl | sort -n -k 16,16 | sort -s -k 14,14 > cdna.f.sorted.psl
blat2hints.pl --in=cdna.f.sorted.psl --out=hints.E.gff
