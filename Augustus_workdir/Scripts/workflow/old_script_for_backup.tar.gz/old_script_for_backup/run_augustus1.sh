#!/bin/bash
#PBS -N run_augustus1
#PBS -l ncpus=16,walltime=12:00:00,storage=gdata/if89+gdata/xl04,mem=50GB,jobfs=50GB
#PBS -j oe
#PBS -M z5205618@ad.unsw.edu.au
#PBS -m ae

# This script takes ~7hrs to run
# variables needed when running qsub
# ${workingdir}     path/to/working_directory
# ${species}        your species name, use _ if there is a space

source ~/.bashrc
conda activate parallelforkmanager
module use /g/data/if89/apps/modulefiles
module load Augustus/3.4.0 perllib/v5.26.3 blat/37 RepeatMasker/4.1.2-p1 scipio/1.4 pblat/2.5 pslCDnaFilter/0 parallel/20191022

cd ${workingdir}
rsync -a $AUGUSTUS_CONFIG_PATH/ Augustus/config/
export AUGUSTUS_CONFIG_PATH=${workingdir}/Augustus/config

# First we make parameters files for the new species
new_species.pl --species=${species}
## an initial training using ~4500 genes, this is fast
cd Augustus/training
etraining --species=${species} ${workingdir}/Exonerate/annotation/CDS_only/training.gb.train
augustus --species=${species} ${workingdir}/Exonerate/annotation/CDS_only/training.gb.test | tee first_evaluation.out
grep -A 22 Evaluation first_evaluation.out > first_evaluation.report

# Now we optimize with 500 genes, 200 for evaluation and all 500 for training, the max 5 rounds has been chosen but it will finish earlier if no improvement are found
## the file optimize.out can be opened for inspection as the job runs to check for progression
optimize_augustus.pl \
--species=${species} \
--cpus=${PBS_NCPUS} \
--rounds=5 \
${workingdir}/Exonerate/annotation/CDS_only/training.gb.test.test \
--onlytrain=${workingdir}/Exonerate/annotation/CDS_only/training.gb.test.train \
> optimize.out

# Retrain after optimization
etraining --species=${species} ${workingdir}/Exonerate/annotation/CDS_only/training.gb.test
