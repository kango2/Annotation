#!/bin/bash
#PBS -N create_training_set2
#PBS -l ncpus=16,walltime=2:00:00,storage=gdata/if89+gdata/xl04,mem=50GB
#PBS -j oe
#PBS -M z5205618@ad.unsw.edu.au
#PBS -m ae

# variables needed when running qsub
# ${workingdir}      path/to/working_directory

# for this step we only need to do blastp all vs all to filter out related transcripts
# name your filtered peptide fasta file from R studio as "peptide_filtered.fa" (default) and put it in ${workingdir}

module use /g/data/if89/apps/modulefiles
module load blast/2.11.0 Augustus/3.4.0 perllib/v5.26.3 blat/37 RepeatMasker/4.1.2-p1 scipio/1.4 pblat/2.5 pslCDnaFilter/0 parallel/20191022 genometools/1.6.2

# all vs all peptide, filtering to keep only one entry in each cluster of transcript
cp ${workingdir}/peptide_filtered.fa ${workingdir}/Trinity_filter/second_filter/database
cp ${workingdir}/peptide_filtered.fa ${workingdir}/Trinity_filter/second_filter/blast
## making database
cd ${workingdir}/Trinity_filter/second_filter/database
makeblastdb -in ${workingdir}/Trinity_filter/second_filter/database/peptide_filtered.fa \
-parse_seqids \
-title "peptide_filtered" -dbtype prot \
-out ${workingdir}/Trinity_filter/second_filter/database/peptide_filtered
## running blastp
cd ${workingdir}/Trinity_filter/second_filter/blast
blastp -query ${workingdir}/Trinity_filter/second_filter/blast/peptide_filtered.fa \
-db ${workingdir}/Trinity_filter/second_filter/database/peptide_filtered \
-parse_deflines \
-outfmt 6 \
-num_threads ${PBS_NCPUS} \
-out ${workingdir}/Trinity_filter/second_filter/blast/all_vs_all_out.tsv
## remove redundant file
cd ${workingdir}
rm peptide_filtered.fa

# continue by downloading all_vs_all_out.tsv to your R studio folder and continue with create_training_set1.5.sh.R
# filter the all_vs_all_out.tsv in R, this will run commands to restrict results to e-values < 1e-6 and pid >= 80%
# then continue with create_training_set3.sh