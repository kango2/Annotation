library(seqinr)
library(tidyverse)
library(tidyr)
library(dplyr)
writeFasta<-function(data, filename){
  fastaLines = c()
  for (rowNum in 1:nrow(data)){
    fastaLines = c(fastaLines, as.character(paste(">", data[rowNum,"name"], sep = "")))
    fastaLines = c(fastaLines,as.character(data[rowNum,"seq"]))
  }
  fileConn<-file(filename)
  writeLines(fastaLines, fileConn)
  close(fileConn)
}

CDS <- read.fasta(file = "Trinity_all.cds.all.fa",
                  as.string = TRUE,
                  whole.header = TRUE,
                  forceDNAtolower = FALSE)
CDS1 <- data.frame(ID=names(CDS), sequence=as.character(CDS))
CDS2 <- CDS1 %>% separate("ID", c("ID", "Useful_info"),
                          sep="(?<=])", extra="merge")
CDS2 <- CDS2 %>% separate("Useful_info", c("CDS_start","CDS_end","Strand","Start_codon","Stop_codon","Relative_length"),
                          sep=":", extra = "merge")
CDS2 <- CDS2 %>% separate("ID", c("ID","Transcript_length","Path"),
                          sep=" ", extra = "merge")
names(CDS2)[10] <- 'CDS_sequences'

PEP <- read.fasta(file = "Trinity_all.pep.all.fa",
                  as.string = TRUE,
                  whole.header = TRUE,
                  seqtype = "AA")

PEP1 <- data.frame(ID=names(PEP), peptide_sequences=as.character(PEP))
PEP1 <- PEP1 %>% separate("ID", c("ID","Transcript_length","Path"),
                          sep=" ", extra = "merge")

PEP1 <- PEP1[-c(2,3)]

CDNA <- read.fasta(file = "Trinity_all.cdna.all.fa",
                   as.string = TRUE,
                   whole.header = TRUE,
                   forceDNAtolower = FALSE)
CDNA1 <- data.frame(ID=names(CDNA), cDNA_sequences=as.character(CDNA))
CDNA1 <- CDNA1 %>% separate("ID", c("ID","Transcript_length","Path"),
                            sep=" ", extra = "merge")

ALL <- left_join(CDNA1,CDS2, by = "ID")
ALL1 <- left_join(ALL,PEP1, by ="ID")
##reordering column
ALL1 <- select(ALL1, ID,Transcript_length.x,Transcript_length.y,Path.x,Path.y,CDS_start,CDS_end,Strand,Start_codon,Stop_codon,Relative_length,cDNA_sequences,CDS_sequences,peptide_sequences)
ALL2 <- ALL1 %>% drop_na(Transcript_length.y)
ALL2 <- select(ALL2, ID, Transcript_length.x,Path.x,CDS_start,CDS_end,Strand,Start_codon,Stop_codon,Relative_length,cDNA_sequences,CDS_sequences,peptide_sequences)
names(ALL2)[2] <- 'Transcript_length'
names(ALL2)[3] <- 'Path'
ALL2$CDS_start <- as.numeric(ALL2$CDS_start)
ALL2$CDS_end <- as.numeric(ALL2$CDS_end)
ALL2$CDS_length = ALL2$CDS_end-ALL2$CDS_start
#filtering
ALL3 <- ALL2 %>% filter(Start_codon == "yes")
ALL3 <- ALL3 %>% filter(Stop_codon == "yes")
ALL4 <- ALL3 %>% filter(Relative_length >= 0.95)
#avoid fused transcripts
ALL4 <- ALL4 %>% filter(Relative_length <= 1.05)
ALL4 <- ALL4 %>% filter(Relative_length != "NA")
ALL4 <- select(ALL4, ID,Transcript_length,Path,CDS_length,CDS_start,CDS_end,Strand,Start_codon,Stop_codon,Relative_length,cDNA_sequences,CDS_sequences,peptide_sequences)
#selecting transcript isoform with longest CDS
ALL5 <- ALL4 %>%
  separate(ID, into = c("gene","isoform"), sep = "(?=_i)")
ALL5 <- ALL5 %>% group_by(gene) %>% top_n(1, CDS_length)
#now selecting transcript isoform with longest transcript length
ALL6 <- ALL5 %>%
  separate(Transcript_length, into = c("len", "length"), sep = "(?<==)")
ALL6$length <- as.numeric(ALL6$length)
ALL6 <- ALL6 %>% group_by(gene) %>% slice(which.max(length))
#arbitrary pruning of very long transcripts
ALL6 <- ALL6 %>% filter(length <= 10000)
#output dataframe to original information and merges column
filtered_output <- ALL6
filtered_output$ID <- paste(filtered_output$gene,filtered_output$isoform,sep="")
filtered_output$ID <- paste(filtered_output$ID,filtered_output$len,sep=" ")
filtered_output$ID <- paste(filtered_output$ID,filtered_output$length,sep="")
filtered_output$ID <- paste(filtered_output$ID,filtered_output$Path,sep=" ")

pep_filtered <- select(filtered_output, ID, peptide_sequences)
pep_filtered <- pep_filtered[,-1]

colnames(pep_filtered)[c(1,2)] <- c("name","seq")
#put the peptide_filtered.fa file in your working directory
writeFasta(pep_filtered, "peptide_filtered.fa")



#Continue with the following after create_training_set2.sh
allvsall <- read.table(file = "all_vs_all_out.tsv")
colnames(allvsall)[c(1:12)] <- c("query","subject","percentage_of_identical_match","alignment_length","number_of_mismatch","number_of_gap_opening","start_of_alignment_in_query","end_of_alignment_in_query","start_of_alignment_in_subject","end_of_alignment_in_subject","expect_value","bit_score")

allvsall2 <- allvsall %>% filter(query != subject)
allvsall2 <- allvsall2 %>% filter(percentage_of_identical_match >= 80)
#filtering for e value < 1e-6
allvsall3 <- allvsall2 %>% filter(expect_value < 1e-6)
#put the table.csv file in your working directory
write.csv(allvsall3, file = "table.csv")



#Continue with the following after create_training_set3.sh
cluster <- read.table(file = "cluster4.txt", header=F)
colnames(cluster)[1] <- "gene"
cluster$remove <- "Yes"

ALL7 <- ALL6
ALL7$gene <- paste(ALL7$gene,ALL7$isoform,sep="")
ALL8 <- left_join(ALL7,cluster, by = "gene")
ALL8$remove <- ALL8$remove %>% replace_na("keep")
ALL9 <- ALL8 %>% filter(remove == "keep")

filtered_output2 <- ALL9
filtered_output2$ID <- paste(filtered_output2$gene,filtered_output2$len,sep=" ")
filtered_output2$ID <- paste(filtered_output2$ID,filtered_output2$length,sep="")
filtered_output2$ID <- paste(filtered_output2$ID,filtered_output2$Path,sep=" ")

cDNA_filtered2 <- select(filtered_output2, ID, cDNA_sequences)
cDNA_filtered2 <- cDNA_filtered2[,-1]
pep_filtered2 <- select(filtered_output2, ID, peptide_sequences)
pep_filtered2 <- pep_filtered2[,-1]
cds_filtered2 <- select(filtered_output2, ID, CDS_sequences)
cds_filtered2 <- cds_filtered2[,-1]

colnames(pep_filtered2)[c(1,2)] <- c("name","seq")
writeFasta(pep_filtered2, "peptide_filtered_final.fa")
colnames(cDNA_filtered2)[c(1,2)] <- c("name","seq")
writeFasta(cDNA_filtered2, "cDNA_filtered_final.fa")
colnames(cds_filtered2)[c(1,2)] <- c("name","seq")
writeFasta(cds_filtered2, "CDS_filtered_final.fa")
