#!/bin/bash
#PBS -N run_augustus4
#PBS -l ncpus=12,walltime=2:00:00,storage=gdata/if89+gdata/xl04,mem=60GB,jobfs=60GB
#PBS -j oe
#PBS -M z5205618@ad.unsw.edu.au
#PBS -m ae

# variables needed
# ${workingdir} path/to/working/directory
# ${anolis}     path/to/anolis/cDNA
# ${genome}     path/to/genome

# This script prepares the candidates for stitching

module use /g/data/if89/apps/modulefiles
module load Augustus/3.4.0 perllib/v5.26.3 blat/37 RepeatMasker/4.1.2-p1 scipio/1.4 pblat/2.5 pslCDnaFilter/0 parallel/20191022 blast/2.11.0
module load genometools/1.6.2 seqkit/2.3.1 gffread/0.12.7

# First, we blast anolis cDNA to bassiana genome
## making database
cd ${workingdir}/Augustus/annotation_stitch/blast/database
makeblastdb -in ${genome} \
-parse_seqids \
-title "genome" -dbtype nucl \
-out ${workingdir}/Augustus/annotation_stitch/blast/database/genome

## blast anolis cDNA to genome
blastn -query ${anolis} \
-db ${workingdir}/Augustus/annotation_stitch/blast/database/genome \
-max_target_seqs 1 \
-evalue 1e-6 \
-parse_deflines \
-outfmt 6 \
-num_threads ${PBS_NCPUS} \
-out ${workingdir}/Augustus/annotation_stitch/blast/anolis_cDNA_to_genome.tsv

cd ${workingdir}/Augustus/annotation_stitch/blast/
# Add gene id immediately following the transcript id, separated by "|" , then turns the blast tsv output into a bed file
join <(sort anolis_cDNA_to_genome.tsv) <(grep ">" ${anolis} | cut -f1,4 -d' ' | sed 's/ /\t/g' | sed 's/>//g' | sort) -t $'\t' -o1.1,2.2,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,1.10,1.11,1.12,1.13,1.14 | perl -pe 's/\t/|/' | perl -lne '@a=split("\t", $_); print "$a[1]\t". (($a[8] < $a[9]) ? $a[8] : $a[9] )."\t".(($a[8] < $a[9]) ? $a[9] : $a[8])."\t$a[0]\t$a[11]\t".(($a[8] < $a[9]) ? "+" : "-" )' > anolis_cDNA_to_genome.bed
mv anolis_cDNA_to_genome.bed ${workingdir}/Augustus/annotation_stitch/intersect_and_stitch/anolis_cDNA_to_genome.bed

# Generating the list of genes to be stitched together
cd ${workingdir}/Augustus/annotation_stitch/intersect_and_stitch
awk -F "\t" '{print $1"\t"$4"\t"$5"\t"$9"\t"$6"\t"$7}' ../../annotation/augustus_for_bedintersect.gff3 > augustus.bed
module load bedtools/2.28.0

# -s so it's strand specific, -wa and -wb to output both input bed files.
bedtools intersect -a anolis_cDNA_to_genome.bed -b augustus.bed -wa -wb -s > intersect

cut -f4,10 intersect | sed 's/;/\t/g' | cut -f1,3 | sed 's/Parent=//g' | sed 's/\.t1//g' | sort | uniq | sort | awk '{ printf "%s", (NR==1 || pre!=$1? (NR>1? ORS:"")$1: "") OFS $2; pre=$1 }
    END  { print "" }' | sed 's/ /\t/g' | awk 'NF>=3' > intersect2
cut -f2- -d "|" intersect2 | sort | uniq > intersect3.tsv

# Since the annotation file are in order, the IDs we grep will also be in order, this generates a long list of .tsv file of consecutive IDs
grep gene ../../annotation/augustus.gff3 | grep "+" | cut -f9 | sed 's/;//g' | sed 's/ID=//g' | paste -s -d "\t" > consecutive_positive.tsv
grep gene ../../annotation/augustus.gff3 | grep "-" | cut -f9 | sed 's/;//g' | sed 's/ID=//g' | paste -s -d "\t" > consecutive_negative.tsv

# We now try grep-ing each intersect cluster from the consecutive IDs, cluster contains neighbouring genes (consecutive IDs) if it can be grep-ed from the consecutive IDs
## we then filter for clusters that can be grep-ed (with yes)
cut -f2- intersect3.tsv | while read a; do if grep -q "$a" consecutive_positive.tsv; then echo -e yes'\t'"$a"; else echo -e no'\t'"$a"; fi done > intersect4_pos.tsv
grep yes intersect4_pos.tsv | cut -f2- | sort | uniq > intersect5_pos.tsv
cat intersect5_pos.tsv | while read -r a; do OCCUR=$(grep "${a}" intersect5_pos.tsv | wc -l); echo -e $OCCUR'\t'"${a}"; done | awk '$1 == 1 {print ;}' | cut -f2- > intersect6_pos.tsv

cut -f2- intersect3.tsv | while read a; do if grep -q "$a" consecutive_negative.tsv; then echo -e yes'\t'"$a"; else echo -e no'\t'"$a"; fi done > intersect4_neg.tsv
grep yes intersect4_neg.tsv | cut -f2- | sort | uniq > intersect5_neg.tsv
cat intersect5_neg.tsv | while read -r a; do OCCUR=$(grep "${a}" intersect5_neg.tsv | wc -l); echo -e $OCCUR'\t'"${a}"; done | awk '$1 == 1 {print ;}' | cut -f2- > intersect6_neg.tsv



cd ${workingdir}/Augustus/annotation_stitch
export temppath=${workingdir}/Augustus/annotation_stitch/temp
sed -i "s|inputpath|${temppath}|g" process.pl

# This generates a "temp_all" file with all the stitched genes
## stitching all the clusters on positive strand
cd ${workingdir}/Augustus/annotation_stitch
cat intersect_and_stitch/intersect6_pos.tsv | while read a; do last=$(echo $a | wc -w); one=1; lastone=$[last - one]; echo "$a" > temp_input; perl -i -pe "chomp if eof" temp_input; readarray -d $'\t' -t a < temp_input; for index in "${!a[@]}"; do if [ $index == 0 ]; then    \
$(grep -w "${a[$index]}" ../annotation/augustus.gff3 | grep 'gene\|mRNA\|transcription_start_site\|five_prime_utr\|start_codon\|CDS\|intron' > temp); \
elif [ $index == $lastone ]; then \
$(grep -w "${a[$index]}" ../annotation/augustus.gff3 | grep 'transcription_end_site\|stop_codon\|three_prime_utr\|CDS\|intron' | sed "s/${a[$index]}/${a[0]}/g" >> temp); \
else \
$(grep -w "${a[$index]}" ../annotation/augustus.gff3 | grep 'CDS\|intron' | sed "s/${a[$index]}/${a[0]}/g" >> temp); \
fi done; gt gff3 -sort -tidy -retainids -addintrons <(sed 's/CDS/exon/g' temp) > temp2; grep "$(cut -f3,4,5 temp2 | grep intron | sort | uniq -u)" temp2 >> temp; gt gff3 -sort -tidy -retainids temp | grep -v "#" > temp2; endcoord=$(sort -n -r -k 5 temp2 | cut -f5 | head -n 1); \
perl process.pl | awk '$2=="."{$2="Inferred"} 1' OFS="\t" | awk '$3=="gene"{$5='$endcoord'} 1' OFS="\t" | awk '$3=="mRNA"{$5='$endcoord'} 1' OFS="\t" > temp3; \
cat temp3 >> temp_all; \
rm temp; \
rm temp2; \
rm temp3; done

## stitching all the clusters on negative strand
cd ${workingdir}/Augustus/annotation_stitch
cat intersect_and_stitch/intersect6_neg.tsv | while read a; do last=$(echo $a | wc -w); one=1; lastone=$[last - one]; echo "$a" > temp_input; perl -i -pe "chomp if eof" temp_input; readarray -d $'\t' -t a < temp_input; for index in "${!a[@]}"; do if [ $index == 0 ]; then    \
$(grep -w "${a[$index]}" ../annotation/augustus.gff3 | grep 'gene\|mRNA\|transcription_end_site\|three_prime_utr\|stop_codon\|CDS\|intron' > temp); \
elif [ $index == $lastone ]; then \
$(grep -w "${a[$index]}" ../annotation/augustus.gff3 | grep 'transcription_start_site\|start_codon\|five_prime_utr\|CDS\|intron' | sed "s/${a[$index]}/${a[0]}/g" >> temp); \
else \
$(grep -w "${a[$index]}" ../annotation/augustus.gff3 | grep 'CDS\|intron' | sed "s/${a[$index]}/${a[0]}/g" >> temp); \
fi done; gt gff3 -sort -tidy -retainids -addintrons <(sed 's/CDS/exon/g' temp) > temp2; grep "$(cut -f3,4,5 temp2 | grep intron | sort | uniq -u)" temp2 >> temp; gt gff3 -sort -tidy -retainids temp | grep -v "#" > temp2; endcoord=$(sort -n -r -k 5 temp2 | cut -f5 | head -n 1); \
perl process.pl | awk '$2=="."{$2="Inferred"} 1' OFS="\t" | awk '$3=="gene"{$5='$endcoord'} 1' OFS="\t" | awk '$3=="mRNA"{$5='$endcoord'} 1' OFS="\t" > temp3; \
cat temp3 >> temp_all; \
rm temp; \
rm temp2; \
rm temp3; done

rm temp_input

# Script to get rid of all those single genes before stitching together
tr '\t' '\n' < intersect_and_stitch/intersect6_pos.tsv > single.lst
tr '\t' '\n' < intersect_and_stitch/intersect6_neg.tsv >> single.lst
sort single.lst | uniq > single2.lst
grep -v -w -f single2.lst ../annotation/augustus.gff3 > augustus2.gff3

# Now we merge augustus2.gff3 (which does not have those single genes), and temp_all (which contains those single genes but stitched), then sort them with genometools
gt gff3 -retainids -tidy <(cat augustus2.gff3 temp_all) > augustus_stitched.gff3

# Generating protein fasta for the stitched annotation
gffread -y temporary.fa -g ${genome} augustus_stitched.gff3

seqtk seq -l 60 temporary.fa | seqkit sort -N > augustus_stitched_protein.fa

# gffread uses full stop to represent ambiguous amino acids, which is not ideal, changing it to the standard "X"
sed -i '/^[^>]/s/\./X/g' augustus_stitched_protein.fa
rm temporary.fa

