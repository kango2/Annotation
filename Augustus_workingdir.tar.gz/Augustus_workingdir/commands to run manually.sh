# These are commands to generate the directory structure needed to run the augustus workflow
# First run the following commands in the terminal
# commands beginning with "export" requires you changing the variable manually
export workingdir=/path/to/working_directory
cd ${workingdir}
rsync -a /g/data/xl04/jc4878/augustus_workflow_directory_structure/ ./
wget https://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_sprot.fasta.gz
gunzip uniprot_sprot.fasta.gz

# set up required parameters as shell variables
# exclude space characters in your species name, use underscore character instead
# check project code with  echo $PROJECT
export targetgenome=/path/to/softmasked_genome.fa
export trinity_out=/path/to/trinity.fa
export species=Species_name
export project_code=xl04

#### now run the first script
cd ${workingdir}/Scripts/workflow
## NOTE, you might want to add PBS mailing directive so that it sends you email notification when the job script finishes, run the next 3 lines if this is wanted, skip to line 25 if otherwise
export email="your email"
sed -i "5i\\#PBS -M ${email}" Part*
sed -i '6i\\#PBS -m ae' Part*

## Now run the first part of annotation, copy paste the following command
qsub -P ${project_code} -v workingdir=${workingdir},targetgenome=${targetgenome},trinity_out=${trinity_out},species=${species},project_code=${project_code} Part1_trainingset.sh

# follow the instruction and run the commands at the end of the log file in ${workingdir}annotation.log
# this log file will be generated and updated once your first script runs